﻿namespace LAB6
{
    public struct Main
    {
        public float Temp { get; set; }
    }
}