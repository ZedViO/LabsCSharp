﻿namespace LAB6
{
    public struct Sys
    {
        public string? Country { get; set; }
    }
}