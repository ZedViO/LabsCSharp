﻿namespace LAB6
{
    public struct Weather
    {
        public string Description { get; set; }
    }
}