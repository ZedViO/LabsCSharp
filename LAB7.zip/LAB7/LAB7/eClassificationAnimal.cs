﻿namespace LAB7
{
    [Comment("Класс перечисления типов животного потребления")]
    public enum eClassificationAnimal
    {
        Herbivores,
        Carnivores,
        Omnivores
    }
}
