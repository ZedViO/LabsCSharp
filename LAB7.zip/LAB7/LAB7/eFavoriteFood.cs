﻿namespace LAB7
{
    [Comment("Класс перечисления любимой еды животных")]
    public enum eFavoriteFood
    {
        Meat,
        Plants,
        Everything
    }
}
